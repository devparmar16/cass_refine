
// import React, { createContext, useContext, useState, ReactNode } from "react";
// import { MOCK_EVENTS, EVENT_TEMPLATE } from "../data/mockData";
// 
// import { useAuth } from "./AuthContext";
// import { useToast } from "@/components/ui/use-toast";

// [];
// }

// const EventsContext = createContext<EventsContextType | undefined>(undefined);

// export function EventsProvider({ children }: { children }) {
//   const [events, setEvents] = useState<Event[]>(MOCK_EVENTS);
//   const [currentEvent, setCurrentEvent] = useState<Event | null>(null);
//   const { currentUser } = useAuth();
//   const { toast } = useToast();

//   const createEvent = (name description eventDate) => {
//     if (!currentUser) return;

//     const newEvent = {
//       id: `event-${events.length + 1}`,
//       name,
//       description,
//       eventDate,
//       createdAt Date(),
//       createdBy.id,
//       status: "draft",
//       phases.parse(JSON.stringify(EVENT_TEMPLATE.phases)), // Deep copy of template
//     };

//     setEvents([...events, newEvent]);
//     setCurrentEvent(newEvent);
    
//     toast({
//       title: "Event created",
//       description: `"${name}" h created successfully`,
//     });
//   };

//   const findTask = (taskId): { event; phase; task } | null => {
//     for (const event of events) {
//       for (let phaseIndex = 0; phaseIndex < event.phases.length; phaseIndex++) {
//         const phase = event.phases[phaseIndex];
//         for (let taskIndex = 0; taskIndex < phase.tasks.length; taskIndex++) {
//           if (phase.tasks[taskIndex].id === taskId) {
//             return { event, phase task };
//           }
//         }
//       }
//     }
//     return null;
//   };

//   const updateTaskStatus = (taskId status"status"]) => {
//     const result = findTask(taskId);
//     if (!result) return;

//     const { event, phase, task } = result;
    
//     const updatedEvents = [...events];
//     const eventIndex = events.findIndex(e => e.id === event.id);
    
//     updatedEvents[eventIndex] = {
//       ...event,
//       phases...event.phases],
//     };
    
//     updatedEvents[eventIndex].phases[phase] = {
//       ...event.phases[phase],
//       tasks...event.phases[phase].tasks],
//     };
    
//     updatedEvents[eventIndex].phases[phase].tasks[task] = {
//       ...event.phases[phase].tasks[task],
//       status,
//     };

//     setEvents(updatedEvents);
    
//     if (currentEvent?.id === event.id) {
//       setCurrentEvent(updatedEvents[eventIndex]);
//     }
    
//     toast({
//       title: "Task updated",
//       description: `Task status changed to ${status.replace('_', ' ')}`,
//     });
//   };

//   const uploadTaskDocument = (taskId fileName fileUrl) => {
//     if (!currentUser) return;
    
//     const result = findTask(taskId);
//     if (!result) return;

//     const { event, phase, task } = result;
//     const taskObj = event.phases[phase].tasks[task];
    
//     // Check if the current user h to upload
//     if (taskObj.assignedRole !== currentUser.role) {
//       toast({
//         title: "Permission denied",
//         description: `Only ${taskObj.assignedRole} can upload documents for this task`,
//         variant: "destructive",
//       });
//       return;
//     }
    
//     const updatedEvents = [...events];
//     const eventIndex = events.findIndex(e => e.id === event.id);
    
//     updatedEvents[eventIndex] = {
//       ...event,
//       phases...event.phases],
//     };
    
//     updatedEvents[eventIndex].phases[phase] = {
//       ...event.phases[phase],
//       tasks...event.phases[phase].tasks],
//     };
    
//     updatedEvents[eventIndex].phases[phase].tasks[task] = {
//       ...event.phases[phase].tasks[task],
//       fileUrl,
//       fileName,
//       uploadedAt Date(),
//       uploadedBy.id,
//       status: 'pending_approval',
//     };

//     setEvents(updatedEvents);
    
//     if (currentEvent?.id === event.id) {
//       setCurrentEvent(updatedEvents[eventIndex]);
//     }
    
//     toast({
//       title: "Document uploaded",
//       description: `${fileName} h uploaded and is pending approval`,
//     });
//   };

//   const approveTask = (taskId status comments?) => {
//     if (!currentUser) return;
    
//     const result = findTask(taskId);
//     if (!result) return;

//     const { event, phase, task } = result;
//     const taskObj = event.phases[phase].tasks[task];
    
//     // Check if the current user h to approve
//     if (!taskObj.requiredApprovals.includes(currentUser.role)) {
//       toast({
//         title: "Permission denied",
//         description: `You don't have permission to approve this task`,
//         variant: "destructive",
//       });
//       return;
//     }
    
//     // Check if user already approved
//     const alreadyApproved = taskObj.approvals.some(
//       (approval) => approval.role === currentUser.role
//     );
    
//     if (alreadyApproved) {
//       toast({
//         title: "Already reviewed",
//         description: `You have already reviewed this task`,
//         variant: "destructive",
//       });
//       return;
//     }
    
//     const newApproval = {
//       role.role,
//       status,
//       timestamp Date(),
//       comments,
//     };
    
//     const updatedEvents = [...events];
//     const eventIndex = events.findIndex(e => e.id === event.id);
    
//     updatedEvents[eventIndex] = {
//       ...event,
//       phases...event.phases],
//     };
    
//     updatedEvents[eventIndex].phases[phase] = {
//       ...event.phases[phase],
//       tasks...event.phases[phase].tasks],
//     };
    
//     const updatedTask = {
//       ...event.phases[phase].tasks[task],
//       approvals...event.phases[phase].tasks[task].approvals, newApproval],
//     };
    
//     // Check if all required approvals are completed
//     const allApproved = taskObj.requiredApprovals.every((role) => {
//       // Check if this role already approved or is the current approver
//       return (
//         updatedTask.approvals.some((a) => a.role === role && a.status === "approved") ||
//         (currentUser.role === role && status === "approved")
//       );
//     });
    
//     if (allApproved) {
//       updatedTask.status = "completed";
//     }
    
//     updatedEvents[eventIndex].phases[phase].tasks[task] = updatedTask;

//     setEvents(updatedEvents);
    
//     if (currentEvent?.id === event.id) {
//       setCurrentEvent(updatedEvents[eventIndex]);
//     }
    
//     toast({
//       title === "approved" ? "Task approved" : "Task rejected",
//       description === "approved" 
//         ? "Task h approved successfully" 
//         : `Task w: ${comments || "No comments provided"}`,
//     });
//   };

//   const lockEvent = (eventId) => {
//     if (!currentUser || currentUser.role !== "Chair") {
//       toast({
//         title: "Permission denied",
//         description: "Only the Chair can lock events",
//         variant: "destructive",
//       });
//       return;
//     }
    
//     const eventIndex = events.findIndex((e) => e.id === eventId);
//     if (eventIndex === -1) return;
    
//     const updatedEvents = [...events];
//     updatedEvents[eventIndex] = {
//       ...events[eventIndex],
//       status: "locked",
//     };
    
//     setEvents(updatedEvents);
    
//     if (currentEvent?.id === eventId) {
//       setCurrentEvent(updatedEvents[eventIndex]);
//     }
    
//     toast({
//       title: "Event locked",
//       description: "The event h locked and cannot be modified",
//     });
//   };

//   const getTasksByRole = (role): { event; task }[] => {
//     const tasks: { event; task }[] = [];
    
//     events.forEach((event) => {
//       if (event.status === "locked") return;
      
//       event.phases.forEach((phase) => {
//         phase.tasks.forEach((task) => {
//           if (task.assignedRole === role) {
//             tasks.push({ event, task });
//           }
//         });
//       });
//     });
    
//     return tasks;
//   };

//   return (
//     <EventsContext.Provider 
//       value={{ 
//         events, 
//         currentEvent, 
//         setCurrentEvent, 
//         createEvent, 
//         updateTaskStatus,
//         uploadTaskDocument,
//         approveTask,
//         lockEvent,
//         getTasksByRole
//       }}
//     >
//       {children}
//     </EventsContext.Provider>
//   );
// }

// export function useEvents() {
//   const context = useContext(EventsContext);
//   if (context === undefined) {
//     throw new Error("useEvents must be used within an EventsProvider");
//   }
//   return context;
// }
