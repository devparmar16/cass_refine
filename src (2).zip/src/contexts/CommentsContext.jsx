import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

const CommentsContext = createContext();

export const CommentsProvider = ({ children }) => {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchComments = async () => {
      setLoading(true);
      const { data, error } = await supabase.from('comments').select('*');
      
      // Parse comment_type if it's a JSON string
      let parsedData = data || [];
      if (parsedData.length > 0) {
        parsedData = parsedData.map(comment => {
          if (comment.comment_type && typeof comment.comment_type === 'string') {
            try {
              comment.comment_type = JSON.parse(comment.comment_type);
            } catch (e) {
              console.warn('[CommentsContext] Failed to parse comment_type:', comment.comment_type);
            }
          }
          return comment;
        });
      }
      
      setComments(parsedData);
      setLoading(false);
    };
    fetchComments();

    // Optional: subscribe to real-time changes
    const subscription = supabase
      .channel('realtime:comments')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'comments' }, fetchComments)
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, []);

  return (
    <CommentsContext.Provider value={{ comments, loading }}>
      {children}
    </CommentsContext.Provider>
  );
};

export const useComments = () => useContext(CommentsContext); 