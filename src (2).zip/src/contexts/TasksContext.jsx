import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

const TasksContext = createContext();

export const TasksProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTasks = async () => {
      setLoading(true);
      console.log('[DEBUG][TasksContext] Fetching tasks from database...');
      const { data, error } = await supabase.from('tasks').select('*');
      console.log('[DEBUG][TasksContext] Database response:', { data, error });
      console.log('[DEBUG][TasksContext] Setting tasks:', data || []);
      setTasks(data || []);
      setLoading(false);
    };
    fetchTasks();

    // Optional: subscribe to real-time changes
    const subscription = supabase
      .channel('realtime:tasks')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tasks' }, fetchTasks)
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, []);

  return (
    <TasksContext.Provider value={{ tasks, loading }}>
      {children}
    </TasksContext.Provider>
  );
};

export const useTasks = () => useContext(TasksContext); 