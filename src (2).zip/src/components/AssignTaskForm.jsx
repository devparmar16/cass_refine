import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';

const AVAILABLE_ROLES = [
  'Chair Person',
  'Vice Chair Person',
  'Secretary',
  'Treasurer',
  'Social Media Manager',
  'Technical Coordinator',
  'Event Coordinator',
];

export default function AssignTaskForm({ eventId, onSuccess }) {
  const [formData, setFormData] = useState({
    name: '',
    task_desc: '',
    assigned_to: '',
  });
  const [reviewers, setReviewers] = useState([]);
  const [submitting, setSubmitting] = useState(false);

  const handleAddReviewer = (role) => {
    if (!reviewers.includes(role)) {
      setReviewers([...reviewers, role]);
    }
  };

  const handleRemoveReviewer = (role) => {
    setReviewers(reviewers.filter(r => r !== role));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.assigned_to || reviewers.length === 0) {
      alert('Please fill task name, assigned role, and at least one reviewer.');
      return;
    }

    setSubmitting(true);
    try {
      // Find or create workflow template
      const workflowHash = reviewers.join('>');
      let { data: template, error: templateError } = await supabase
        .from('review_flow_templates')
        .select('*')
        .eq('workflow_hash', workflowHash)
        .single();

      let flow_template_id;
      if (template) {
        flow_template_id = template.id;
      } else {
        // Create new template
        const { data: newTemplate, error: newTemplateError } = await supabase
          .from('review_flow_templates')
          .insert([{
            name: `Review Flow for ${formData.name}`,
            workflow_hash: workflowHash,
            created_at: new Date().toISOString()
          }])
          .select()
          .single();
        if (newTemplateError || !newTemplate) throw newTemplateError || new Error('Failed to create template');
        flow_template_id = newTemplate.id;

        // Insert reviewer steps
        const steps = reviewers.map((role, idx) => ({
          template_id: flow_template_id,
          step_order: idx,
          reviewer_role: role,
        }));
        const { error: stepsError } = await supabase
          .from('review_flow_template_steps')
          .insert(steps);
        if (stepsError) throw stepsError;
      }

      // Create task
      const { error: taskError } = await supabase
        .from('tasks_temp')
        .insert([{
          task_name: formData.name,
          task_desc: formData.task_desc,
          event_id: eventId,
          assigned_to: formData.assigned_to,
          flow_template_id,
          current_step: 0,
          current_reviewer_role: null,
          status: 'assigned',
        }]);
      if (taskError) throw taskError;

      alert('Task assigned successfully!');
      setFormData({ name: '', task_desc: '', assigned_to: '' });
      setReviewers([]);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error(err);
      alert('Failed to assign task: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 border rounded p-4 mb-4">
      <h3 className="text-lg font-semibold mb-3">Assign Task (Chair Only)</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="block text-sm font-medium mb-1">Task Name *</label>
          <input
            type="text"
            className="border p-2 w-full rounded"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
        </div>
        <div className="mb-3">
          <label className="block text-sm font-medium mb-1">Task Description</label>
          <textarea
            className="border p-2 w-full rounded"
            rows="3"
            value={formData.task_desc}
            onChange={(e) => setFormData({ ...formData, task_desc: e.target.value })}
          />
        </div>
        <div className="mb-3">
          <label className="block text-sm font-medium mb-1">Assigned To *</label>
          <select
            className="border p-2 w-full rounded"
            value={formData.assigned_to}
            onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
            required
          >
            <option value="">Select role</option>
            {AVAILABLE_ROLES.map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label className="block text-sm font-medium mb-1">Reviewer Chain * (in order)</label>
          <div className="flex gap-2 flex-wrap mb-2">
            {reviewers.map((r, idx) => (
              <div key={idx} className="flex items-center gap-1 bg-blue-100 px-2 py-1 rounded">
                <span className="text-xs">{idx + 1}. {r}</span>
                <button type="button" onClick={() => handleRemoveReviewer(r)} className="text-red-500 text-xs">✕</button>
              </div>
            ))}
          </div>
          <select
            className="border p-2 w-full rounded"
            onChange={(e) => {
              if (e.target.value) {
                handleAddReviewer(e.target.value);
                e.target.value = '';
              }
            }}
          >
            <option value="">Add reviewer</option>
            {AVAILABLE_ROLES.filter(r => !reviewers.includes(r)).map(r => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>
        <Button type="submit" disabled={submitting}>
          {submitting ? 'Assigning...' : 'Assign Task'}
        </Button>
      </form>
    </div>
  );
}
