import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { getTaskComments } from '@/lib/taskQueries';

const TaskCard = ({ task, userRole, onUpload }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loadingComment, setLoadingComment] = useState(false);
  const [uploading, setUploading] = useState(false);

  const isAssignedToMe = task.assigned_to === userRole;
  const isReviewer = task.current_reviewer_role === userRole;

  // Enhanced upload handler that sets first reviewer
  const handleUploadClick = async () => {
    if (onUpload) {
      setUploading(true);
      await onUpload(task);
      setUploading(false);
    }
  };

  const fetchComments = async () => {
    try {
      const data = await getTaskComments(task.id);
      setComments(data);
    } catch (err) {
      console.error('Error fetching comments:', err);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [task.id]);

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    setLoadingComment(true);
    try {
      const { error } = await supabase
        .from('task_comments')
        .insert([{
          task_id: task.id,
          comment_text: newComment,
          commenter_role: userRole,
          created_at: new Date().toISOString()
        }]);
      if (error) throw error;
      setNewComment('');
      fetchComments();
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingComment(false);
    }
  };

  const handleAcceptReject = async (action, comment = '') => {
    try {
      // Get all review steps for this task's workflow
      const { data: steps, error: stepsError } = await supabase
        .from('review_flow_template_steps')
        .select('*')
        .eq('template_id', task.flow_template_id)
        .order('step_order', { ascending: true });

      if (stepsError) throw stepsError;

      let update = {};
      let nextStep = (task.current_step || 0) + 1;

      if (action === 'accept') {
        if (nextStep >= steps.length) {
          // All reviewers done - task goes to "Uploaded" tab of assigned_to role
          update = {
            status: 'uploaded',
            current_reviewer_role: null,
            current_step: nextStep
          };
          console.log('[TaskCard] All reviews complete, moving to uploaded');
        } else {
          // Move to next reviewer
          update = {
            status: 'in_review',
            current_step: nextStep,
            current_reviewer_role: steps[nextStep].reviewer_role
          };
          console.log('[TaskCard] Moving to next reviewer:', steps[nextStep].reviewer_role);
        }
      } else if (action === 'reject') {
        // Rejected - goes back to assigned_to role's "My Tasks"
        update = {
          status: 'rejected',
          current_reviewer_role: null,
          current_step: 0
        };
        console.log('[TaskCard] Task rejected, returning to assignee');
      }

      // Update the task
      const { error: updateError } = await supabase
        .from('tasks_temp')
        .update(update)
        .eq('id', task.id);

      if (updateError) throw updateError;

      // Add comment if provided
      if (comment.trim()) {
        await supabase.from('task_comments').insert([{
          task_id: task.id,
          comment_text: `[${action.toUpperCase()}] ${comment}`,
          commenter_role: userRole,
          created_at: new Date().toISOString()
        }]);
      }

      // Refresh comments
      fetchComments();
      
      // Trigger parent refresh if available
      if (window.location) {
        window.location.reload();
      }
    } catch (err) {
      console.error('Accept/Reject error:', err);
    }
  };

  // State for reject modal
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectComment, setRejectComment] = useState('');

  const handleAccept = () => {
    handleAcceptReject('accept', newComment);
    setNewComment('');
  };

  const handleReject = () => {
    if (rejectComment.trim()) {
      handleAcceptReject('reject', rejectComment);
      setRejectComment('');
      setShowRejectModal(false);
    } else {
      alert('Please provide a reason for rejection');
    }
  };

  return (
    <div className="border rounded p-4 mb-4 shadow">
      <h3 className="font-bold text-lg">{task.task_name}</h3>
      {task.task_desc && <p className="text-gray-700 mb-2">{task.task_desc}</p>}
      <p className="text-sm text-gray-500 mb-2">Status: {task.status}</p>
      <p className="text-sm text-gray-500 mb-2">
        Assigned To: {task.assigned_to} | Current Reviewer: {task.current_reviewer_role || '-'}
      </p>

      {/* Upload Button for assigned role - show for 'assigned' or 'pending' status */}
      {isAssignedToMe && (task.status === 'assigned' || task.status === 'pending') && (
        <button
          className="bg-green-600 text-white px-3 py-1 rounded mr-2 disabled:opacity-50"
          onClick={handleUploadClick}
          disabled={uploading}
        >
          {uploading ? 'Uploading...' : 'Upload'}
        </button>
      )}

      {/* Accept / Reject Buttons for reviewer */}
      {isReviewer && task.status === 'in_review' && (
        <div className="flex gap-2 mt-2">
          <button
            className="bg-blue-600 text-white px-3 py-1 rounded"
            onClick={handleAccept}
          >
            Accept
          </button>
          <button
            className="bg-red-600 text-white px-3 py-1 rounded"
            onClick={() => setShowRejectModal(true)}
          >
            Reject
          </button>
        </div>
      )}

      {/* Comment Box for reviewer */}
      {isReviewer && task.status === 'in_review' && (
        <div className="mt-2">
          <input
            type="text"
            placeholder="Add comment (optional for accept)..."
            value={newComment}
            onChange={e => setNewComment(e.target.value)}
            className="border rounded px-2 py-1 mr-2 w-3/4"
          />
          <button
            onClick={handleAddComment}
            className="bg-gray-700 text-white px-3 py-1 rounded"
            disabled={loadingComment}
          >
            {loadingComment ? 'Adding...' : 'Comment'}
          </button>
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h3 className="font-bold text-lg mb-4">Reject Task</h3>
            <p className="text-sm text-gray-600 mb-2">Please provide a reason for rejection:</p>
            <textarea
              value={rejectComment}
              onChange={e => setRejectComment(e.target.value)}
              className="w-full border rounded p-2 mb-4"
              rows={3}
              placeholder="Enter rejection reason..."
            />
            <div className="flex justify-end gap-2">
              <button
                className="px-4 py-2 bg-gray-300 rounded"
                onClick={() => {
                  setShowRejectModal(false);
                  setRejectComment('');
                }}
              >
                Cancel
              </button>
              <button
                className="px-4 py-2 bg-red-600 text-white rounded"
                onClick={handleReject}
              >
                Reject
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Re-upload button for rejected tasks */}
      {isAssignedToMe && task.status === 'rejected' && (
        <button
          className="bg-orange-500 text-white px-3 py-1 rounded mr-2 disabled:opacity-50"
          onClick={handleUploadClick}
          disabled={uploading}
        >
          {uploading ? 'Re-uploading...' : 'Re-upload'}
        </button>
      )}

      {/* Show comments */}
      {comments.length > 0 && (
        <div className="mt-2 border-t pt-2">
          <h4 className="font-semibold text-sm">Comments:</h4>
          {comments.map(c => (
            <div key={c.id} className="text-sm text-gray-700">
              <strong>{c.commenter_role}:</strong> {c.comment_text}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default TaskCard;
