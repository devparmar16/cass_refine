import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import AssignTaskModal from '@/pages/chair/AssignTaskModal';
import { useAuth } from '@/contexts/AuthContext';
import TaskCard from '@/components/TaskCard';

// Map display roles to database role values
const ROLE_MAP = {
  'Chair Person': 'chair',
  'Vice Chairperson': 'vice_chair',
  'Secretary': 'secretary',
  'Treasurer': 'treasurer',
  'Technical Coordinator': 'technical',
  'Event Coordinator': 'coordinator',
  'Social Media Manager': 'social_media',
};

// Minimal EventTasks page — shows event title, three tabs, and Assign Task modal for Chair
export default function EventTasks() {
  const { eventId, role: urlRole, section } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [tab, setTab] = useState(section || 'mytasks');
  const [refreshKey, setRefreshKey] = useState(0);
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Convert user role to database format
  const currentUserRole = ROLE_MAP[user?.role] || user?.role?.toLowerCase().replace(/\s+/g, '_') || 'chair';

  useEffect(() => {
    const fetchEvent = async () => {
      if (!eventId) return;
      const { data, error } = await supabase.from('events').select('id,event_name').eq('id', eventId).single();
      if (!error) setEvent(data);
    };
    fetchEvent();
  }, [eventId]);

  useEffect(() => {
    setTab(section || 'mytasks');
  }, [section]);

  // Fetch tasks based on current tab
  const fetchTasks = async () => {
    setLoading(true);
    try {
      console.log('[EventTasks] Fetching tasks:', { eventId, currentUserRole, tab });
      
      let query = supabase.from('tasks_temp').select('*').eq('event_id', eventId);

      switch (tab) {
        case 'mytasks':
          // Include 'rejected' so assignee can see and re-upload rejected tasks
          query = query.eq('assigned_to', currentUserRole).in('status', ['assigned', 'pending', 'rejected']);
          break;
        case 'reviews':
          query = query.eq('current_reviewer_role', currentUserRole).eq('status', 'in_review');
          break;
        case 'uploaded':
          query = query.eq('assigned_to', currentUserRole).eq('status', 'uploaded');
          break;
      }

      const { data, error } = await query.order('created_at', { ascending: true });
      console.log('[EventTasks] Query result:', { data, error });
      
      if (error) throw error;
      setTasks(data || []);
    } catch (err) {
      console.error('Error fetching tasks:', err);
      setTasks([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (eventId && currentUserRole) {
      fetchTasks();
    }
  }, [eventId, currentUserRole, tab, refreshKey]);

  const handleTaskAssigned = () => {
    setRefreshKey(k => k + 1);
  };

  const handleUpload = async (task) => {
    try {
      // Get the first reviewer from the workflow template
      const { data: steps, error: stepsError } = await supabase
        .from('review_flow_template_steps')
        .select('reviewer_role')
        .eq('template_id', task.flow_template_id)
        .order('step_order', { ascending: true })
        .limit(1);

      if (stepsError) throw stepsError;

      const firstReviewer = steps?.[0]?.reviewer_role || null;

      // Update task: set status to in_review and assign first reviewer
      const { error } = await supabase
        .from('tasks_temp')
        .update({ 
          status: 'in_review', 
          current_reviewer_role: firstReviewer,
          current_step: 0
        })
        .eq('id', task.id);

      if (error) throw error;
      console.log('[EventTasks] Task uploaded, now in_review with reviewer:', firstReviewer);
      fetchTasks();
    } catch (err) {
      console.error('Upload error:', err);
    }
  };

  // Use actual user role from AuthContext, not URL param
  const userRole = user?.role || 'Chair Person';
  const urlRoleParam = urlRole || user?.role?.replace(/\s+/g, '').toLowerCase() || 'chairperson';

  const navigateToTab = (tabName) => {
    navigate(`/event-tasks/${eventId}/${urlRoleParam}/${tabName}`);
  };

  if (!event) return <div className="p-4">Loading event...</div>;

  return (
    <div className="p-4">
      <div className="flex justify-between items-center mb-4">
        <Button variant="outline" onClick={() => navigate('/events')}>Back to Events</Button>
        
        {/* Chair-only: Assign Task button */}
        {userRole === 'Chair Person' && (
          <Button onClick={() => setShowAssignModal(true)}>
            Assign Task
          </Button>
        )}
      </div>

      <h2 className="text-xl font-bold mb-2">{event.event_name}</h2>
      
      {/* Debug info */}
      <div className="bg-yellow-100 p-2 rounded mb-4 text-sm">
        <strong>Debug:</strong> User: "{user?.role}" → DB Role: "{currentUserRole}" | Event: {eventId}
      </div>

      {/* Chair-only: Assign Task Modal */}
      <AssignTaskModal
        open={showAssignModal}
        onClose={() => setShowAssignModal(false)}
        onTaskAssigned={handleTaskAssigned}
      />

      <div className="mb-4">
        <button 
          className={`px-3 py-1 mr-2 border rounded ${tab === 'mytasks' ? 'bg-blue-500 text-white' : ''}`} 
          onClick={() => navigateToTab('mytasks')}
        >
          My Tasks
        </button>
        <button 
          className={`px-3 py-1 mr-2 border rounded ${tab === 'reviews' ? 'bg-blue-500 text-white' : ''}`} 
          onClick={() => navigateToTab('reviews')}
        >
          Reviews
        </button>
        <button 
          className={`px-3 py-1 border rounded ${tab === 'uploaded' ? 'bg-blue-500 text-white' : ''}`} 
          onClick={() => navigateToTab('uploaded')}
        >
          Uploaded
        </button>
      </div>

      {/* Task list */}
      <div className="mb-4">
        {loading ? (
          <p className="text-gray-500">Loading tasks...</p>
        ) : tasks.length === 0 ? (
          <p className="text-gray-500">No tasks in this section.</p>
        ) : (
          tasks.map(task => (
            <TaskCard
              key={task.id}
              task={task}
              userRole={currentUserRole}
              onUpload={handleUpload}
            />
          ))
        )}
      </div>
    </div>
  );
}

