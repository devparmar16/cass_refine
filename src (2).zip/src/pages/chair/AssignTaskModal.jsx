import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../../lib/supabase'; // Adjust import as needed

const ROLE_OPTIONS = [
  { value: 'chair', label: 'Chair Person' },
  { value: 'vice_chair', label: 'Vice Chairperson' },
  { value: 'secretary', label: 'Secretary' },
  { value: 'treasurer', label: 'Treasurer' },
  { value: 'technical', label: 'Technical Coordinator' },
  { value: 'coordinator', label: 'Event Coordinator' },
  { value: 'social_media', label: 'Social Media Manager' },
];

const reviewerRoleOptions = ROLE_OPTIONS.map(r => ({ value: r.value, label: r.label }));

function hashReviewerChain(chain) {
  // Simple hash for reviewer chain array (order matters)
  return chain.join('>');
}

const AssignTaskModal = ({ open, onClose, onTaskAssigned }) => {
  const { eventId } = useParams();
  const [assignTaskModalState, setAssignTaskModalState] = useState({
    taskName: '',
    taskDesc: '',                 // ✅ NEW
    assignedTo: ROLE_OPTIONS[0].value,
    reviewers: ['chair'],
    loading: false,
    error: '',
  });

  const handleReviewerChange = (idx, value) => {
    setAssignTaskModalState(prev => ({
      ...prev,
      reviewers: prev.reviewers.map((r, i) => (i === idx ? value : r))
    }));
  };

  const addReviewer = () =>
    setAssignTaskModalState(prev => ({
      ...prev,
      reviewers: [...prev.reviewers, 'chair']
    }));

  const removeReviewer = idx =>
    setAssignTaskModalState(prev => ({
      ...prev,
      reviewers: prev.reviewers.filter((_, i) => i !== idx)
    }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setAssignTaskModalState(prev => ({ ...prev, error: '' }));

    if (!assignTaskModalState.taskName.trim()) {
      setAssignTaskModalState(prev => ({ ...prev, error: 'Task name is required.' }));
      return;
    }

    if (!assignTaskModalState.reviewers.length) {
      setAssignTaskModalState(prev => ({ ...prev, error: 'At least one reviewer is required.' }));
      return;
    }

    setAssignTaskModalState(prev => ({ ...prev, loading: true }));

    try {
      const reviewerChainHash = hashReviewerChain(assignTaskModalState.reviewers);

      // 1. Find or create review flow template
      const { data: existingTemplate } = await supabase
        .from('review_flow_templates')
        .select('*')
        .eq('workflow_hash', reviewerChainHash)
        .single();

      let flow_template_id = existingTemplate?.id;

      if (!flow_template_id) {
        const { data: newTemplate, error: templateError } = await supabase
          .from('review_flow_templates')
          .insert([{
            name: `Review Flow - ${assignTaskModalState.taskName}`,
            workflow_hash: reviewerChainHash,
          }])
          .select()
          .single();

        if (templateError) throw templateError;
        flow_template_id = newTemplate.id;

        const steps = assignTaskModalState.reviewers.map((role, idx) => ({
          template_id: flow_template_id,
          step_order: idx,
          reviewer_role: role,
        }));

        const { error: stepsError } = await supabase
          .from('review_flow_template_steps')
          .insert(steps);

        if (stepsError) throw stepsError;
      }

      // 2. Insert task
      const { error: taskError } = await supabase
        .from('tasks_temp')
        .insert([{
          task_name: assignTaskModalState.taskName,
          task_desc: assignTaskModalState.taskDesc,     // ✅ NEW
          assigned_to: assignTaskModalState.assignedTo,
          event_id: eventId,
          flow_template_id,
          current_step: 0,
          current_reviewer_role: null,
          status: 'assigned',
        }]);

      if (taskError) throw taskError;

      setAssignTaskModalState({
        taskName: '',
        taskDesc: '',           // ✅ RESET
        assignedTo: ROLE_OPTIONS[0].value,
        reviewers: ['chair'],
        loading: false,
        error: '',
      });

      onTaskAssigned?.();
      onClose();

    } catch (err) {
      setAssignTaskModalState(prev => ({
        ...prev,
        error: err.message || 'Failed to assign task',
      }));
    } finally {
      setAssignTaskModalState(prev => ({ ...prev, loading: false }));
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
      <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-lg relative">
        <button onClick={onClose} className="absolute top-2 right-2 text-gray-400">&times;</button>

        <h2 className="text-xl font-bold mb-4">Assign Task</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Task Name */}
          <div>
            <label className="font-medium">Task Name</label>
            <input
              className="w-full border rounded px-3 py-2"
              value={assignTaskModalState.taskName}
              onChange={e => setAssignTaskModalState(p => ({ ...p, taskName: e.target.value }))}
              required
            />
          </div>

          {/* ✅ Task Description */}
          <div>
            <label className="font-medium">Task Description</label>
            <textarea
              className="w-full border rounded px-3 py-2"
              rows={3}
              value={assignTaskModalState.taskDesc}
              onChange={e => setAssignTaskModalState(p => ({ ...p, taskDesc: e.target.value }))}
            />
          </div>

          {/* Event ID */}
          <div>
            <label className="font-medium">Event ID</label>
            <input className="w-full border rounded px-3 py-2 bg-gray-100" value={eventId} readOnly />
          </div>

          {/* Assign To */}
          <div>
            <label className="font-medium">Assign To</label>
            <select
              className="w-full border rounded px-3 py-2"
              value={assignTaskModalState.assignedTo}
              onChange={e => setAssignTaskModalState(p => ({ ...p, assignedTo: e.target.value }))}
            >
              {ROLE_OPTIONS.map(r => (
                <option key={r.value} value={r.value}>{r.label}</option>
              ))}
            </select>
          </div>

          {/* Reviewers */}
          <div>
            <label className="font-medium">Reviewers (order matters)</label>
            {assignTaskModalState.reviewers.map((role, idx) => (
              <div key={idx} className="flex gap-2 mb-2">
                <select
                  className="flex-1 border rounded px-3 py-2"
                  value={role}
                  onChange={e => handleReviewerChange(idx, e.target.value)}
                >
                  {reviewerRoleOptions.map(r => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
                {idx === assignTaskModalState.reviewers.length - 1 && (
                  <button type="button" onClick={addReviewer}>+</button>
                )}
                {assignTaskModalState.reviewers.length > 1 && (
                  <button type="button" onClick={() => removeReviewer(idx)}>-</button>
                )}
              </div>
            ))}
          </div>

          {assignTaskModalState.error && (
            <p className="text-red-600">{assignTaskModalState.error}</p>
          )}

          <button
            type="submit"
            className="bg-blue-600 text-white px-4 py-2 rounded"
            disabled={assignTaskModalState.loading}
          >
            {assignTaskModalState.loading ? 'Assigning...' : 'Assign Task'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default function ChairPersonAssignTaskFeature() {
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <div>
      <button
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        onClick={() => setModalOpen(true)}
      >
        Assign Task
      </button>
      <AssignTaskModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        onTaskAssigned={() => {
          // Optionally refresh task list or show a toast
        }}
      />
    </div>
  );
}