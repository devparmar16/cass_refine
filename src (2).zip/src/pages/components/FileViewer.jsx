import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../../components/ui/dialog';
import { Button } from '../../components/ui/button';

function getFileType(url) {
  if (!url || typeof url !== 'string') return '';
  const ext = url.split('.').pop().toLowerCase();
  if (["xlsx", "xls", "docx", "pptx"].includes(ext)) return 'office';
  if (["pdf"].includes(ext)) return 'pdf';
  if (["jpg", "jpeg", "png", "gif", "bmp", "webp"].includes(ext)) return 'image';
  return 'other';
}

export default function FileViewer({ files, tableData, taskName = '', buttonLabel = 'View', variant = 'outline', buttonClass = '', docType, links }) {
  console.log('🔍 DEBUG - FileViewer: Received files prop:', files, 'type:', typeof files, 'isArray:', Array.isArray(files));
  const [showModal, setShowModal] = useState(false);
  const [modalFiles, setModalFiles] = useState([]);
  const [showTableModal, setShowTableModal] = useState(false);
  const [showLinksModal, setShowLinksModal] = useState(false);
  const [showTableOptions, setShowTableOptions] = useState(false);

  // Normalize files to array of { url, name }
  let fileArr = files;
  
  if (Array.isArray(fileArr)) {
    if (fileArr.length > 0 && typeof fileArr[0] === 'string') {
      fileArr = fileArr.map(url => ({ url }));
    }
  } else if (fileArr && typeof fileArr === 'object' && fileArr.url) {
    fileArr = [fileArr];
  } else if (typeof fileArr === 'string') {
    fileArr = [{ url: fileArr }];
  } else {
    fileArr = [];
  }

  const hasTable = tableData && Array.isArray(tableData.columns) && Array.isArray(tableData.rows);

  // Handle link type
  const isLinkType = docType === 'link';
  const hasLinks = links && Array.isArray(links) && links.length > 0;

  const handleView = () => {
    if (isLinkType || hasLinks) {
      setShowLinksModal(true);
      return;
    }
    
    // If there's table data and files, show options dialog
    if (hasTable && fileArr.length > 0) {
      setShowTableOptions(true);
      return;
    }
    
    // If there's only table data (no files), show table modal directly
    if (hasTable && fileArr.length === 0) {
      setShowTableModal(true);
      return;
    }
    
    // Always show file list modal for files (single or multiple)
    if (fileArr.length > 0) {
      console.log('🔍 DEBUG - FileViewer: Setting modalFiles to:', fileArr);
      setModalFiles(fileArr);
      setShowModal(true);
      return;
    }
  };

  // Show button if there are files, table data, or links
  if ((!fileArr || fileArr.length === 0) && !hasTable && !isLinkType && !hasLinks) return null;



  const handleExcelPreview = () => {
    if (fileArr.length > 0) {
      const officeFile = fileArr.find(f => getFileType(f.url || f) === 'office');
      if (officeFile) {
        const fileUrl = officeFile.url || officeFile;
        window.open(`https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(fileUrl)}`, '_blank');
      } else {
        // If no Office file, open the first file
        const firstFile = fileArr[0];
        const fileUrl = firstFile.url || firstFile;
        const fileType = getFileType(fileUrl);
        if (fileType === 'office') {
          window.open(`https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(fileUrl)}`, '_blank');
        } else {
          window.open(fileUrl, '_blank');
        }
      }
    }
    setShowTableOptions(false);
  };

  const handleTablePreview = () => {
    setShowTableModal(true);
    setShowTableOptions(false);
  };

  return (
    <>
      <Button size="sm" variant={variant} className={buttonClass} onClick={handleView} data-testid="fileviewer-view-btn">
        {buttonLabel}
      </Button>
      {/* Modal for multiple files */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent style={{ maxWidth: 600, minWidth: 400 }}>
          <DialogHeader>
            <DialogTitle>Files for: {taskName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4" style={modalFiles.length > 5 ? { maxHeight: 350, overflowY: 'auto' } : {}}>
            {console.log('🔍 DEBUG - FileViewer Modal: modalFiles:', modalFiles, 'length:', modalFiles?.length)}
            {(!modalFiles || modalFiles.length === 0) ? (
              <div className="text-gray-500">No files uploaded.</div>
            ) : (
              modalFiles.map((file, idx) => {
                const fileUrl = file.url || file;
                const type = getFileType(fileUrl);
                return (
                  <div key={idx} className="flex items-center gap-2 p-2 border rounded">
                    <span className="flex-1 break-all">{file.name || (typeof fileUrl === 'string' ? fileUrl.split('/').pop() : 'Unknown file')}</span>
                    <Button size="sm" variant="outline" onClick={() => {
                      if (type === 'office') {
                        window.open(`https://view.officeapps.live.com/op/view.aspx?src=${encodeURIComponent(fileUrl)}`, '_blank');
                      } else if (type === 'pdf' || type === 'image') {
                        window.open(fileUrl, '_blank');
                      } else {
                        window.open(fileUrl, '_blank');
                      }
                    }}>View</Button>
                    <Button size="sm" variant="ghost" onClick={async () => {
                      try {
                        const response = await fetch(fileUrl);
                        const blob = await response.blob();
                        const blobUrl = URL.createObjectURL(blob);
                        const link = document.createElement('a');
                        link.href = blobUrl;
                        link.download = file.name || (typeof fileUrl === 'string' ? fileUrl.split('/').pop() : 'file');
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        URL.revokeObjectURL(blobUrl);
                      } catch (err) {
                        alert(`Download failed: ${err.message}`);
                      }
                    }}>Download</Button>
                  </div>
                );
              })
            )}
          </div>
        </DialogContent>
      </Dialog>
      {/* Modal for table data */}
      <Dialog open={showTableModal} onOpenChange={setShowTableModal}>
        <DialogContent style={{ maxWidth: 800, minWidth: 400 }}>
          <DialogHeader>
            <DialogTitle>Table for: {taskName}</DialogTitle>
          </DialogHeader>
          {hasTable ? (
            <div style={{ overflowX: 'auto', maxHeight: 400, overflowY: tableData.rows.length > 10 ? 'auto' : 'visible' }}>
              <table className="min-w-full border text-sm">
                <thead>
                  <tr>
                    {tableData.columns.map((col, idx) => (
                      <th key={idx} className="border px-2 py-1 bg-gray-100">{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {tableData.rows.map((row, rIdx) => (
                    <tr key={rIdx}>
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="border px-2 py-1">{cell}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-gray-500">No table data available.</div>
          )}
        </DialogContent>
      </Dialog>
      {/* Modal for links */}
      <Dialog open={showLinksModal} onOpenChange={setShowLinksModal}>
        <DialogContent style={{ maxWidth: 600, minWidth: 400 }}>
          <DialogHeader>
            <DialogTitle>Links for: {taskName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {(!links || links.length === 0) ? (
              <div className="text-gray-500">No links available.</div>
            ) : (
              links.map((link, idx) => (
                <div key={idx} className="flex items-center gap-2 p-2 border rounded">
                  <span className="flex-1 break-all font-medium">{link.name || link.url}</span>
                  <a href={link.url} target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">Open</a>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
      {/* Options dialog for table data with files */}
      <Dialog open={showTableOptions} onOpenChange={setShowTableOptions}>
        <DialogContent style={{ maxWidth: 500, minWidth: 400 }}>
          <DialogHeader>
            <DialogTitle className="text-lg font-bold">Choose Preview Option for: {taskName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-gray-600 mb-4 p-3 bg-blue-50 rounded-lg">
              <strong>Multiple Preview Options Available:</strong><br/>
              This task has both table data and associated files. Choose how you'd like to preview the content:
            </div>
            <div className="flex flex-col gap-4">
              <Button 
                onClick={handleExcelPreview}
                className="flex items-center gap-3 justify-start h-12 text-base"
                variant="outline"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <div className="text-left">
                  <div className="font-semibold">Preview in Excel/File</div>
                  <div className="text-xs text-gray-500">Open the Excel file in browser</div>
                </div>
              </Button>
              <Button 
                onClick={handleTablePreview}
                className="flex items-center gap-3 justify-start h-12 text-base"
                variant="outline"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                </svg>
                <div className="text-left">
                  <div className="font-semibold">Preview Table Data</div>
                  <div className="text-xs text-gray-500">View data in table format</div>
                </div>
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
} 